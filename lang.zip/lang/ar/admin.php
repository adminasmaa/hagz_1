<?php

return [
    'Login' => 'تسجيل الدخول',
    'Enter your email & password to login'=>'ادخل الايميل والباسورد'
];